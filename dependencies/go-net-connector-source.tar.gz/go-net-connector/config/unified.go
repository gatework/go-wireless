package config

import (
	"maps"
	"reflect"
)

// UnifiedName discovers one flat policy for every user-facing command.
const UnifiedName = "net-connector"

func policyFields(name string) map[string]Field {
	if name != UnifiedName {
		return schema
	}
	fields := maps.Clone(schema)
	delete(fields, "backup.parallel")
	delete(fields, "topology.parallel")
	delete(fields, "topology.cache_mode")
	fields["parallel"] = Field{Env: "NC_PARALLEL", Kind: "integer"}
	return fields
}

// Named Ruby policies remain readable when explicitly selected. Their common
// settings must converge rather than silently differ by action.
func unifyPolicy(m map[string]any) error {
	for _, section := range []string{"backup", "topology"} {
		values, ok := m[section].(map[string]any)
		if !ok {
			continue
		}
		if err := unifyField(values, "parallel", m, "parallel"); err != nil {
			return err
		}
	}
	if topology, ok := m["topology"].(map[string]any); ok {
		if _, present := topology["cache_mode"]; present {
			netdisco, ok := m["netdisco"].(map[string]any)
			if !ok {
				if m["netdisco"] != nil {
					return ErrInvalid
				}
				netdisco = map[string]any{}
				m["netdisco"] = netdisco
			}
			return unifyField(topology, "cache_mode", netdisco, "cache_mode")
		}
	}
	return nil
}

func unifyField(source map[string]any, oldKey string, target map[string]any, key string) error {
	if value := source[oldKey]; value != nil {
		if shared := target[key]; shared != nil && !reflect.DeepEqual(shared, value) {
			return ErrInvalid
		}
		target[key] = value
	}
	delete(source, oldKey)
	return nil
}

func unifiedEnvironment(environment map[string]string) map[string]string {
	owned := maps.Clone(environment)
	for key, legacy := range map[string]string{"NC_PARALLEL": "NC_TOPOLOGY_PARALLEL", "ND_CACHE_MODE": "NC_TOPOLOGY_CACHE_MODE"} {
		if _, present := owned[key]; !present {
			if value, ok := owned[legacy]; ok {
				owned[key] = value
			}
		}
	}
	return owned
}
