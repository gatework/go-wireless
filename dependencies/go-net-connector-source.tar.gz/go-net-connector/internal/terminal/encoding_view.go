package terminal

import (
	"strings"
	"unicode/utf8"
)

// ByteIssue identifies a contiguous invalid UTF-8 span in the source. Offset
// is zero-based; line and byte column are one-based. No source bytes are exposed
// in diagnostics. The authoritative source is retained separately by callers.
type ByteIssue struct {
	Offset, Line, ByteColumn, Bytes int
}

type EncodingView struct {
	Text                   string
	InvalidBytes, Segments int
	Locations              []ByteIssue
}

// EscapeUTF8 leaves all valid text (including literal backslashes and U+FFFD)
// untouched and displays each invalid byte as \xNN. This is a readable view,
// not a substitute for the original bytes or a guess at missing characters.
// Locations are capped independently from the total warning counters.
func EscapeUTF8(input string) EncodingView {
	if utf8.ValidString(input) {
		return EncodingView{Text: input}
	}
	const maxLocations = 64
	const hex = "0123456789ABCDEF"
	var output strings.Builder
	output.Grow(len(input))
	view := EncodingView{}
	line, column := 1, 1
	for offset := 0; offset < len(input); {
		r, n := utf8.DecodeRuneInString(input[offset:])
		if r == utf8.RuneError && n == 1 {
			issue := ByteIssue{Offset: offset, Line: line, ByteColumn: column}
			for offset < len(input) {
				r, n = utf8.DecodeRuneInString(input[offset:])
				if r != utf8.RuneError || n != 1 {
					break
				}
				b := input[offset]
				output.WriteString(`\x`)
				output.WriteByte(hex[b>>4])
				output.WriteByte(hex[b&15])
				offset++
				column++
				issue.Bytes++
			}
			view.InvalidBytes += issue.Bytes
			view.Segments++
			if len(view.Locations) < maxLocations {
				view.Locations = append(view.Locations, issue)
			}
			continue
		}
		output.WriteString(input[offset : offset+n])
		offset += n
		if r == '\n' {
			line++
			column = 1
		} else {
			column += n
		}
	}
	view.Text = output.String()
	return view
}
