package terminal

import (
	"bytes"
	"strings"
	"unicode/utf8"

	"golang.org/x/text/encoding/simplifiedchinese"
)

// DecodeConfiguration prefers UTF-8. A vendor may opt into reversible GB18030
// (including GBK) fallback. A complete or truncated UTF-8 run is ambiguous: it
// can also happen to round-trip through GB18030.
// Never silently reinterpret such a run as unrelated legacy characters.
func DecodeConfiguration(input, fallback string) (text, encoding string, err error) {
	if utf8.ValidString(input) {
		return input, "utf-8", nil
	}
	if fallback != "gb18030" || hasUTF8Run(input) {
		return "", "", ErrEncoding
	}
	decoded, e := simplifiedchinese.GB18030.NewDecoder().Bytes([]byte(input))
	if e != nil || !utf8.Valid(decoded) || bytes.ContainsRune(decoded, utf8.RuneError) {
		return "", "", ErrEncoding
	}
	encoded, e := simplifiedchinese.GB18030.NewEncoder().Bytes(decoded)
	if e != nil || !bytes.Equal(encoded, []byte(input)) {
		return "", "", ErrEncoding
	}
	return string(decoded), "gb18030", nil
}

func hasUTF8Run(input string) bool {
	for len(input) > 0 {
		start := strings.IndexFunc(input, func(r rune) bool { return r >= utf8.RuneSelf })
		if start < 0 {
			return false
		}
		input = input[start:]
		i := 0
		for i < len(input) && input[i] >= utf8.RuneSelf {
			i++
		}
		run := input[:i]
		if utf8.ValidString(run) {
			return true
		}
		for offset := 0; offset < len(run); {
			_, n := utf8.DecodeRuneInString(run[offset:])
			if n == 1 {
				if !utf8.FullRuneInString(run[offset:]) {
					return true
				}
				break
			}
			offset += n
		}
		input = input[i:]
	}
	return false
}
