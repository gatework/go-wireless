// Package display translates trusted status codes for human-readable output.
// Machine fields retain their stable codes; arbitrary error text is never used.
package display

import (
	"fmt"
	"github.com/gatework/go-net-connector/connector"
)

const OriginalBytesNote = "配置编码无法无损确认，已保留原始字节；本台备份未完成，需核对设备原文"
const DecodedConfigNote = "已将 GBK/GB18030 中文配置转为 UTF-8，原始配置及校验摘要已保留"

func BackupEncodingNote(b *connector.BackupReceipt) string {
	if b == nil {
		return ""
	}
	stored := (b.File.Durable() || b.DeviceCompleted && b.NoWriteVerified) && b.Source != nil && b.Source.File.Durable()
	if w := b.TextWarning; w != nil {
		note := fmt.Sprintf("原始配置有 %d 处异常编码（%d 字节）", w.Segments, w.Bytes)
		if stored {
			note += `；UTF-8 文本已用 \xNN 标记，原始字节完整保留`
		}
		return note
	}
	if stored && b.Source.Encoding == "gb18030" {
		return DecodedConfigNote
	}
	if b.Encoding == "original_bytes" {
		return OriginalBytesNote
	}
	return ""
}

func label(values map[string]string, code, fallback string) string {
	if value, ok := values[code]; ok {
		return value
	}
	return fallback
}

func Status(code string) string { return label(statuses, code, "未知状态") }
func Error(code string) string  { return label(errors, code, "未分类错误") }

// Reason also covers planning exclusions, which have a status but no device
// error diagnostic. Unknown values are never echoed into human output.
func Reason(code string) string { return label(errors, code, label(statuses, code, "未分类错误")) }
func Mode(code string) string {
	return label(map[string]string{"backup": "配置备份", "tftp": "TFTP 配置备份", "topology": "接口描述维护", "inventory": "设备清单", "plan": "规划", "discover": "发现", "apply": "应用并核验"}, code, "未知操作")
}
func Policy(code string) string {
	return label(map[string]string{"selected": "全部选中设备成功", "strict": "全部清单设备成功", "verified": "全部选中设备的服务器文件核验成功"}, code, "未知策略")
}
func Yes(value bool) string {
	if value {
		return "是"
	}
	return "否"
}

// Advice is category-specific and intentionally excludes credentials and raw
// SSH/device errors. It describes the next check without claiming a root cause.
func Advice(code string) string {
	switch code {
	case "authentication_error", "authentication_failed":
		return "核对设备账号、密码和 AAA/登录权限；避免反复重试导致账号锁定。"
	case "login_timeout":
		return "检查 SSH 服务是否返回握手信息及登录提示，并检查访问控制和会话数；确认服务响应后再调整登录超时。"
	case "connection_error", "connection_failed", "connection_refused", "connection_reset", "connection_timeout", "no_route", "transport_error", "connection_closed":
		return "检查网络可达性、设备管理端口和 SSH 服务状态。"
	case "host_key_changed", "host_key_untrusted":
		return "通过可信渠道核对设备主机密钥，再更新 known_hosts。"
	case "invalid_output_encoding":
		return "核对设备配置原文和历史备份；完整 GBK/GB18030 可无损转码，残缺或编码不明的内容需确认原文后修复。"
	case "command_timeout", "write_timeout", "prompt_error":
		return "检查设备负载、命令响应和提示符；确认原因后再调整超时。"
	case "incomplete_configuration", "startup_config_missing", "unrecognized_output":
		return "检查账号的配置读取权限和设备返回内容是否完整。"
	case "unsupported_operation", "unsupported_vendor", "missing_profile", "unsupported_configuration_format":
		return "检查设备厂商、型号及该操作的支持范围。"
	case "duplicate_host":
		return "检查并合并设备清单中的重复地址，再重新选择设备。"
	case "invalid_address":
		return "修正设备清单中无效或缺失的 IP 地址。"
	case "remote_filename_collision":
		return "检查 TFTP 目标文件名，避免不同设备写入同一远程文件。"
	case "file_write_failed", "backup_persistence_error", "backup_persistence_unconfirmed", "file_persistence_unconfirmed", "backup_durability_unsupported", "directory_sync_unsupported", "backup_finalize_failed", "file_finalize_failed", "log_error":
		return "检查产物目录的空间、权限和文件系统状态；先核对已有文件及回执。"
	case "transfer_failed", "transfer_unconfirmed", "transfer_path_mismatch", "transfer_path_unconfirmed", "tftp_completion_error", "transfer_finalize_failed", "tftp_archive_failed", "tftp_history_unavailable":
		return "核对 TFTP 服务器文件、路径和归档回执；设备报告上传完成不代表服务器文件已核验。"
	default:
		return "查看设备明细和诊断阶段，确认原因后再处理。"
	}
}

var statuses = map[string]string{
	"": "未提供", "ready": "可用", "backed_up": "备份成功", "reported_uploaded": "设备报告已上传",
	"saved_with_error": "已保存但备份未完成", "reported_with_error": "已报告上传但收尾异常",
	"failed": "失败", "interrupted": "已中断", "filtered": "不符合筛选条件", "sample_limit": "超过抽样数量",
	"unsupported_vendor": "暂不支持该厂商", "invalid_address": "设备地址无效", "duplicate": "重复设备",
	"duplicate_host": "重复地址", "missing_profile": "缺少连接类型", "unsupported_operation": "暂不支持该操作",
	"complete": "完成", "completed": "完成", "success": "成功", "incomplete": "未完成", "empty": "无设备",
	"pending": "待处理", "skipped": "已跳过", "planned": "已生成计划", "discovered": "已发现",
	"collected": "已采集", "unchanged": "无需修改", "applied": "已应用并核验", "review_required": "待核验",
	"matched": "一致", "match": "一致", "content_mismatch": "描述不一致", "format_mismatch": "格式不一致",
	"missing": "缺失", "unverified": "未核验", "verified": "已核验", "no_neighbor": "无邻居信息",
	"needs_change": "需要修改", "no_change": "无需修改", "not_committed": "未提交", "committed": "已提交", "durable": "已持久化",
	"matches": "描述一致", "missing_description": "缺少描述", "partial": "部分完成", "partial_applied": "部分应用",
	"partial_planned": "已生成部分计划", "manual_required": "需要人工处理", "not_started": "尚未开始",
	"missing_credentials": "缺少登录凭据", "remote_filename_collision": "远程文件名冲突",
	"succeeded": "成功", "no_devices": "无设备",
}

var errors = map[string]string{
	"": "未提供错误分类", "error": "操作异常", "connection_error": "连接失败", "connection_failed": "连接失败",
	"authentication_error": "认证失败", "authentication_failed": "认证失败", "login_timeout": "登录超时",
	"command_timeout": "命令响应超时", "write_timeout": "命令发送超时", "prompt_error": "提示符识别失败",
	"connection_closed": "连接已关闭", "transport_error": "传输异常", "device_error": "设备拒绝命令",
	"configuration_error": "配置无效", "script_error": "脚本执行异常", "internal_error": "内部处理异常",
	"output_limit_exceeded": "命令响应超过大小限制", "script_output_limit_exceeded": "脚本响应超过大小限制",
	"session_busy": "设备会话忙", "unsupported_operation": "暂不支持该操作", "log_error": "日志写入失败",
	"parsing_error": "解析失败", "backup_busy": "备份正在进行", "backup_persistence_error": "备份持久化失败",
	"backup_finalize_error": "备份收尾失败", "tftp_completion_error": "TFTP 上传收尾失败",
	"connection_refused": "连接被拒绝", "no_route": "无可用路由", "connection_reset": "连接被重置", "connection_timeout": "连接超时",
	"host_key_changed": "主机密钥已变更", "host_key_untrusted": "主机密钥未受信任",
	"known_hosts_busy": "主机密钥文件正被占用", "known_hosts_unsafe": "主机密钥文件不安全", "known_hosts_inherited": "主机密钥来源不符合策略",
	"rsa_too_small": "RSA 密钥长度不足", "unsupported_cipher": "不支持该加密算法", "unsupported_host_key": "不支持该主机密钥算法",
	"ambiguous_description": "接口描述存在歧义", "ambiguous_neighbor": "同一接口存在多个邻居", "confirmation_required": "需要确认",
	"description_stages_unsupported": "不支持该描述修改流程", "description_unconfirmed": "接口描述未确认", "description_unsupported": "不支持接口描述修改",
	"incomplete_configuration": "配置内容不完整", "interface_missing": "配置中缺少本地接口", "neighbor_discovery_unsupported": "不支持邻居发现",
	"parse_failed": "解析失败", "invalid_output_encoding": "响应文本编码无效", "persistence_unconfirmed": "持久化结果未确认", "stale_plan": "计划已过期",
	"startup_config_missing": "缺少启动配置", "template_invalid": "解析模板无效", "template_missing": "缺少解析模板", "template_unreadable": "无法读取解析模板",
	"transfer_failed": "文件传输失败", "transfer_finalize_failed": "文件传输收尾失败", "transfer_path_mismatch": "传输路径不一致",
	"transfer_path_unconfirmed": "传输路径未确认", "transfer_unconfirmed": "传输结果未确认", "uncommitted_configuration": "配置尚未提交",
	"unrecognized_output": "无法识别设备响应", "unsupported_configuration_format": "不支持该配置格式", "verification_plan_changed": "核验时计划已变更",
	"candidate_isolation_unavailable": "无法隔离候选配置", "backup_durability_unsupported": "文件系统不支持备份持久化确认",
	"backup_finalize_failed": "备份收尾失败", "backup_persistence_unconfirmed": "备份持久化结果未确认",
	"file_finalize_failed": "文件收尾失败", "file_persistence_unconfirmed": "文件持久化结果未确认", "file_write_failed": "文件写入失败",
	"directory_sync_unsupported": "文件系统不支持目录同步", "tftp_history_unavailable": "TFTP 历史记录不可用", "tftp_archive_failed": "TFTP 归档失败",
	"unknown_neighbor_name": "缺少邻居名称", "unknown_neighbor_interface": "缺少邻居端口", "unsafe_description": "目标描述不符合安全约束",
	"unsupported_vendor": "暂不支持该厂商", "missing_profile": "缺少连接类型",
}
