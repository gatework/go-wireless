package netdisco

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"github.com/gatework/go-net-connector/internal/display"
	"github.com/gatework/go-net-connector/storage"
	"path/filepath"
	"sort"
	"strings"
	"time"
	"unicode"
)

func (r Report) Text(directory string, p Plan, workers int) string {
	b := r.batch
	s := r.Statistics()
	zone := time.FixedZone("UTC+8", 8*3600)
	title := "网络设备配置备份报告"
	if b.mode == "tftp" {
		title = "网络设备 TFTP 配置备份报告"
	}
	reportError := "无"
	if b.reportError != "" {
		reportError = display.Error(r.diagnostic.safe().ErrorCode)
	}
	lines := []string{title, strings.Repeat("=", 72), "开始时间：" + b.startedAt.In(zone).Format("2006-01-02 15:04:05 -07:00"), "结束时间：" + b.finishedAt.In(zone).Format("2006-01-02 15:04:05 -07:00"), fmt.Sprintf("设备清单：%d 台；本次选中：%d 台；并发：%d", len(p.entries), len(p.tasks), workers), fmt.Sprintf("成功：%v；部分成功：%v；失败：%v；跳过：%v", s["succeeded"], s["partial"], s["failed"], s["skipped"]), fmt.Sprintf("耗时：%.1f 秒；批次状态：%s", b.finishedAt.Sub(b.startedAt).Seconds(), display.Status(b.Status())), fmt.Sprintf("成功策略：%s；是否满足：%s", display.Policy(r.policy), display.Yes(r.Success())), fmt.Sprintf("回调异常：%d；报告异常：%s", len(b.callbackErrors), reportError)}
	counts := b.Counts()
	keys := make([]string, 0, len(counts))
	for k := range counts {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	parts := []string{}
	for _, k := range keys {
		parts = append(parts, fmt.Sprintf("%s=%d", display.Status(k), counts[k]))
	}
	lines = append(lines, "状态统计："+strings.Join(parts, "，"))
	groups := map[string]int{}
	failed := []Outcome{}
	warnings := []Outcome{}
	decoded := []Outcome{}
	for _, o := range b.outcomes {
		if b := o.Artifact.Backup; b != nil && b.Source != nil && b.Source.Encoding == "gb18030" && b.Source.File.Durable() && (b.File.Durable() || b.NoWriteVerified) {
			decoded = append(decoded, o)
		}
		if b := o.Artifact.Backup; b != nil && (b.TextWarning != nil || b.Encoding == "original_bytes") {
			warnings = append(warnings, o)
		}
		if !o.Success() && o.Status != "filtered" && o.Status != "sample_limit" {
			failed = append(failed, o)
			groups[outcomeErrorCode(o)]++
		}
	}
	keys = nil
	for k := range groups {
		keys = append(keys, k)
	}
	sort.Strings(keys)
	parts = nil
	for _, k := range keys {
		parts = append(parts, fmt.Sprintf("%s=%d", display.Reason(k), groups[k]))
	}
	category := "无"
	if len(parts) > 0 {
		category = strings.Join(parts, "，")
	}
	lines = append(lines, "未完成分类："+category)
	for _, code := range keys {
		lines = append(lines, "处理建议（"+display.Reason(code)+"）："+display.Advice(code))
	}
	lines = append(lines, strings.Repeat("-", 72), "未完成设备：")
	for _, o := range failed {
		name := strings.Map(func(c rune) rune {
			if unicode.IsControl(c) {
				return ' '
			}
			return c
		}, o.Device.Name)
		lines = append(lines, fmt.Sprintf("%s | %s | %s | %s | %d 毫秒", o.Device.Host, name, display.Status(o.Status), display.Reason(outcomeErrorCode(o)), o.Duration.Milliseconds()))
	}
	if len(failed) == 0 {
		lines = append(lines, "无")
	}
	if len(warnings) > 0 {
		lines = append(lines, strings.Repeat("-", 72), fmt.Sprintf("编码提示：%d 台；以下位置对应原始文件，列号按字节计算。", len(warnings)))
		for _, o := range warnings {
			b := o.Artifact.Backup
			lines = append(lines, o.Device.Host+" | "+display.BackupEncodingNote(b)+" | UTF-8 文本："+b.Path)
			if b.Source != nil {
				lines = append(lines, "  原始文件："+b.Source.Path)
			}
			if warning := b.TextWarning; warning != nil {
				for _, location := range warning.Locations {
					lines = append(lines, fmt.Sprintf("  第 %d 行，第 %d 字节列；异常长度 %d 字节", location.Line, location.ByteColumn, location.Bytes))
				}
				if warning.LocationsTruncated {
					lines = append(lines, "  仅列出前 64 处异常位置，总数见编码提示。")
				}
			}
		}
	}
	if len(decoded) > 0 {
		lines = append(lines, strings.Repeat("-", 72), fmt.Sprintf("编码转换：%d 台；%s。", len(decoded), display.DecodedConfigNote))
		for _, o := range decoded {
			lines = append(lines, o.Device.Host+" | UTF-8 配置："+o.Artifact.Backup.Path+" | 原始配置："+o.Artifact.Backup.Source.Path)
		}
	}
	if b.mode == "tftp" {
		v := s["verification"].(map[string]int)
		lines = append(lines, fmt.Sprintf("TFTP 服务器文件：已核验 %d 台，未核验 %d 台。", v["verified"], v["unverified"]))
	}
	lines = append(lines, strings.Repeat("=", 72), "备份目录："+directory, "完整明细："+filepath.Join(directory, "summary.json"))
	return strings.Join(lines, "\n") + "\n"
}
func outcomeErrorCode(o Outcome) string {
	d := o.Diagnostic
	if d.ErrorType == "" {
		d.ErrorCode, d.ErrorType = o.ErrorCode, o.ErrorType
	}
	if code := d.safe().ErrorCode; code != "" {
		return code
	}
	return o.Status
}
func WriteReport(ctx context.Context, r Report, directory string, p Plan, workers int) Report {
	destination := filepath.Join(directory, "summary.json")
	final := r
	final.batch.reportLocation = destination
	writeJSON := func(report Report) (storage.Receipt, error) {
		data, e := json.MarshalIndent(report.DisplaySummary(), "", "  ")
		if e != nil {
			return storage.Receipt{}, e
		}
		return storage.Write(ctx, destination, data)
	}
	_, e := storage.Write(ctx, filepath.Join(directory, "summary.txt"), []byte(final.Text(directory, p, workers)))
	var receipt storage.Receipt
	if e == nil {
		receipt, e = writeJSON(final)
	}
	if e == nil {
		return final
	}
	location := r.batch.reportLocation
	if receipt.Committed() {
		location = destination
	}
	var we *storage.WriteError
	if errors.As(e, &we) && we.Receipt.Committed() && we.Receipt.Path == destination {
		location = destination
	}
	failed := r
	failed.batch.reportLocation = location
	if r.batch.reportError == "" {
		failed = r.WithReportError(e, location)
	}
	saved := failed
	saved.batch.reportLocation = destination
	receipt, e = writeJSON(saved)
	if e == nil || receipt.Committed() {
		failed = saved
	}
	_, _ = storage.Write(ctx, filepath.Join(directory, "summary.txt"), []byte(failed.Text(directory, p, workers)))
	return failed
}
func (p Plan) Summary() map[string]any {
	rows := make([]map[string]any, 0, len(p.entries))
	counts := map[string]int{}
	for _, e := range p.entries {
		counts[e.Status]++
		r := e.Device
		rows = append(rows, map[string]any{"host": optional(r.Host), "source_ip": r.SourceIP, "name": optional(r.Name), "vendor": optional(r.Vendor), "source_vendor": optional(r.SourceVendor), "model": optional(r.Model), "os": optional(r.OS), "os_version": optional(r.OSVersion), "serial": optional(r.Serial), "status": e.Status})
	}
	return map[string]any{"mode": p.mode, "total": len(p.entries), "selected": len(p.tasks), "counts": counts, "devices": rows}
}
