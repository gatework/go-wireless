package connector

import (
	"context"
	"crypto/sha256"
	"errors"
	"fmt"
	"os"
	"strings"
	"syscall"
	"time"

	"github.com/gatework/go-net-connector/internal/terminal"
	"github.com/gatework/go-net-connector/storage"
)

type renderedConfig struct{ archiveBytes bool }

func (renderedConfig) Prompt(_ string, current string) string                        { return current }
func (renderedConfig) Validate(context.Context, Command, StepResult, Executor) error { return nil }
func (s renderedConfig) Finish(r Result) (string, error) {
	if len(r.steps) == 0 {
		return "", ErrIncomplete
	}
	if s.archiveBytes {
		return terminal.RenderBytes([]byte(r.steps[len(r.steps)-1].output))
	}
	return terminal.Render([]byte(r.steps[len(r.steps)-1].output), true)
}
func (d *Device) RunningConfig(ctx context.Context) (Result, error) {
	if e := d.acquire(); e != nil {
		return Result{}, e
	}
	defer d.release()
	return d.runningConfig(ctx, false)
}
func (d *Device) runningConfig(ctx context.Context, archiveBytes bool) (result Result, err error) {
	if len(d.profile.ConfigCommands) == 0 {
		return Result{}, fail("configuration_error", "collect", Command{}, ErrUnsupported)
	}
	defer func() {
		if err != nil {
			_ = d.closeResources()
		}
	}()
	commands := make([]Command, len(d.profile.ConfigCommands))
	for i, text := range d.profile.ConfigCommands {
		commands[i] = Command{Text: text, OutputSensitive: true}
	}
	preserveBytes := archiveBytes || d.profile.ConfigEncoding != ""
	var strategy ConfigStrategy = renderedConfig{archiveBytes: preserveBytes}
	if d.profile.ConfigStrategy != nil {
		strategy = d.profile.ConfigStrategy()
		if strategy == nil {
			return Result{}, fail("configuration_error", "collect", Command{}, ErrInvalid)
		}
	}
	result, e := d.execute(ctx, Script{Commands: commands}, ExecuteOptions{}, strategy, preserveBytes)
	if e != nil {
		return result, e
	}
	config, e := strategy.Finish(result)
	if e != nil {
		return result, configurationFailure(Command{}, e)
	}
	if strings.TrimSpace(config) == "" {
		return result, ErrIncomplete
	}
	hasBody := d.profile.ConfigStrategy != nil
	for _, step := range result.steps[len(result.steps)-1:] {
		// Strict collectors already validated UTF-8 during command execution;
		// archives must check completeness without changing configuration bytes.
		body, e := terminal.RenderBytes([]byte(step.output))
		if e != nil {
			return result, e
		}
		prompt, _ := terminal.Render([]byte(step.prompt), true)
		body = strings.TrimSuffix(strings.TrimSpace(body), strings.TrimSpace(prompt))
		body = strings.TrimSpace(body)
		if strings.HasPrefix(body, step.command.Text) {
			body = strings.TrimSpace(strings.TrimPrefix(body, step.command.Text))
		}
		if body != "" {
			hasBody = true
		}
	}
	if !hasBody {
		return result, fail("incomplete_configuration", "collect", Command{}, ErrIncomplete)
	}
	if !archiveBytes {
		config, _, e = terminal.DecodeConfiguration(config, d.profile.ConfigEncoding)
		if e != nil {
			return result, configurationFailure(Command{}, e)
		}
		if int64(len(config)) > d.config.MaxOutputBytes {
			return result, fail("output_limit_exceeded", "collect", Command{}, ErrOutputLimit)
		}
	}
	result.config = &config
	return result, nil
}
func (d *Device) SaveConfig(ctx context.Context, opts ExecuteOptions) (Result, error) {
	if len(d.profile.SaveCommands) == 0 {
		return Result{}, ErrUnsupported
	}
	commands := make([]Command, len(d.profile.SaveCommands))
	for i, text := range d.profile.SaveCommands {
		commands[i] = Command{Text: text}
	}
	return d.ExecuteScript(ctx, Script{Commands: commands}, opts)
}

type BackupOptions struct {
	Path          string
	LockTimeout   time.Duration
	RejectSymlink bool
}
type BackupReceipt struct {
	Path            string    `json:"path"`
	Bytes           int       `json:"bytes"`
	SHA256          string    `json:"sha256"`
	CollectedAt     time.Time `json:"collected_at"`
	Change          string    `json:"change"`
	PreviousSHA256  string    `json:"previous_sha256,omitempty"`
	DeviceCompleted bool      `json:"device_completed"`
	NoWriteVerified bool      `json:"no_write_verified"`
	// Transformed files are UTF-8 views. Source retains the exact configuration
	// bytes; TextWarning distinguishes escaped invalid bytes from decoded text.
	Encoding    string             `json:"encoding,omitempty"`
	Source      *BackupSource      `json:"source,omitempty"`
	TextWarning *BackupTextWarning `json:"text_warning,omitempty"`
	File        storage.Receipt    `json:"file"`
}

type EncodingLocation struct {
	Offset     int `json:"offset"`
	Line       int `json:"line"`
	ByteColumn int `json:"byte_column"`
	Bytes      int `json:"bytes"`
}

// BackupTextWarning describes source encoding defects without publishing
// response bytes in diagnostics. Locations refer to Source, and are bounded.
type BackupTextWarning struct {
	Code               string             `json:"code"`
	Segments           int                `json:"segments"`
	Bytes              int                `json:"bytes"`
	Locations          []EncodingLocation `json:"locations"`
	LocationsTruncated bool               `json:"locations_truncated"`
}

func (w BackupTextWarning) Clone() BackupTextWarning {
	w.Locations = append([]EncodingLocation(nil), w.Locations...)
	return w
}

// BackupSource preserves the exact collected configuration before transcoding.
// Its content-addressed path associates the source with this backup receipt.
type BackupSource struct {
	Path     string          `json:"path"`
	Bytes    int             `json:"bytes"`
	SHA256   string          `json:"sha256"`
	Encoding string          `json:"encoding"`
	File     storage.Receipt `json:"file"`
}

func (d *Device) Backup(ctx context.Context, opts BackupOptions) (receipt BackupReceipt, err error) {
	if d.lease.Load() {
		return receipt, ErrBusy
	}
	lock, e := storage.Acquire(ctx, opts.Path, opts.LockTimeout)
	if e != nil {
		return receipt, e
	}
	defer func() {
		if e := lock.Close(); err == nil && e != nil {
			err = fail("backup_finalize_failed", "backup", Command{}, e)
		}
	}()
	if e = d.acquire(); e != nil {
		return receipt, e
	}
	defer d.release()
	result, e := d.runningConfig(ctx, true)
	if e != nil {
		return receipt, e
	}
	contents, _ := result.Config()
	original := contents
	decoded, encoding, decodeErr := terminal.DecodeConfiguration(contents, d.profile.ConfigEncoding)
	var warning *BackupTextWarning
	if decodeErr == nil {
		contents = decoded
	} else {
		view := terminal.EscapeUTF8(original)
		contents, encoding = view.Text, "unknown"
		warning = &BackupTextWarning{Code: "source_encoding_invalid", Segments: view.Segments, Bytes: view.InvalidBytes, LocationsTruncated: view.Segments > len(view.Locations)}
		for _, location := range view.Locations {
			warning.Locations = append(warning.Locations, EncodingLocation{Offset: location.Offset, Line: location.Line, ByteColumn: location.ByteColumn, Bytes: location.Bytes})
		}
	}
	if int64(len(contents)) > d.config.MaxOutputBytes {
		return receipt, fail("output_limit_exceeded", "backup", Command{}, ErrOutputLimit)
	}
	digest := fmt.Sprintf("%x", sha256.Sum256([]byte(contents)))
	receipt = BackupReceipt{Path: lock.Path(), Bytes: len(contents), SHA256: digest, CollectedAt: time.Now().UTC(), DeviceCompleted: true, File: storage.Receipt{Path: lock.Path(), State: "not_committed", Phase: "compare"}}
	receipt.TextWarning = warning
	_, previous, e := storage.Read(ctx, lock.Path(), d.config.MaxOutputBytes)
	if e != nil && !errors.Is(e, os.ErrNotExist) && !(errors.Is(e, syscall.ELOOP) && !opts.RejectSymlink) {
		return receipt, e
	}
	if contents != original {
		receipt.Encoding = "utf-8"
		sourceDigest := fmt.Sprintf("%x", sha256.Sum256([]byte(original)))
		sourcePath := lock.Path() + "." + sourceDigest + ".raw"
		receipt.Source = &BackupSource{Path: sourcePath, Bytes: len(original), SHA256: sourceDigest, Encoding: encoding}
		if opts.RejectSymlink {
			if info, statErr := os.Lstat(sourcePath); statErr == nil && info.Mode()&os.ModeSymlink != 0 {
				return receipt, storage.ErrUnsafe
			}
		}
		receipt.Source.File, e = storage.Write(ctx, sourcePath, []byte(original))
		if e != nil {
			return receipt, e
		}
	}
	receipt.PreviousSHA256 = previous.SHA256
	switch {
	case previous.SHA256 == "":
		receipt.Change = "created"
	case previous.SHA256 == digest:
		receipt.Change = "unchanged"
	default:
		receipt.Change = "changed"
	}
	if receipt.Change == "unchanged" && previous.Mode.Perm() == 0600 && storage.SameEntry(lock.Path(), previous) {
		receipt.NoWriteVerified = true
		return receipt, nil
	}
	receipt.File, err = storage.Write(ctx, lock.Path(), []byte(contents))
	if err != nil && receipt.File.Committed() {
		code := "backup_persistence_unconfirmed"
		if receipt.File.Durable() {
			code = "backup_finalize_failed"
		}
		if receipt.File.Phase == "directory_sync" && (errors.Is(err, syscall.EINVAL) || errors.Is(err, syscall.ENOSYS) || errors.Is(err, syscall.ENOTSUP) || errors.Is(err, syscall.EOPNOTSUPP)) {
			code = "backup_durability_unsupported"
		}
		err = &BackupPersistenceError{failure: &Error{Code: code, Phase: "backup", cause: err}}
	}
	return
}

// BackupPersistenceError marks a failure after the backup file was committed.
// Backup's returned receipt retains the committed/durable boundary. Unwrap
// preserves the connector metadata and original storage error for explicit use.
// Before commit, Backup returns the original storage.WriteError instead.
type BackupPersistenceError struct{ failure *Error }

func (e *BackupPersistenceError) Error() string    { return e.failure.Error() }
func (e *BackupPersistenceError) GoString() string { return e.Error() }
func (e *BackupPersistenceError) Unwrap() error    { return e.failure }

func configurationFailure(c Command, err error) error {
	var classified *Error
	if errors.As(err, &classified) {
		return err
	}
	if errors.Is(err, ErrIncomplete) {
		return fail("incomplete_configuration", "collect", c, err)
	}
	if errors.Is(err, terminal.ErrEncoding) {
		return fail("invalid_output_encoding", "parse", c, err)
	}
	return fail("configuration_error", "collect", c, err)
}
