// Package resources prepares process-local capacity before starting device batches.
package resources

import (
	"context"
	"errors"
	"fmt"
	"sync"

	"golang.org/x/sys/unix"
)

var ErrParallel = errors.New("resources: parallel must be between 0 and 500")
var ErrInsufficient = errors.New("resources: insufficient local file descriptor limit")

// LimitError contains only the capacity requested by the batch.
type LimitError struct {
	Parallel int
	Required uint64
}

func (e *LimitError) Error() string {
	return fmt.Sprintf("Insufficient local file descriptor limit: %d concurrent devices require at least %d file descriptors; raise the terminal ulimit -n or lower --parallel. Stopped without connecting to devices.", e.Parallel, e.Required)
}
func (e *LimitError) Unwrap() error { return ErrInsufficient }

// The limit belongs to the process, so concurrent batches must share this lock.
var limitMu sync.Mutex

// Prepare reserves 128 base descriptors and 16 per active device, matching Ruby.
// It only raises the soft limit within the existing hard limit. Empty batches
// leave process limits untouched; callers pass min(parallel, selected devices).
func Prepare(ctx context.Context, parallel int) error {
	if parallel < 0 || parallel > 500 {
		return ErrParallel
	}
	if err := ctx.Err(); err != nil {
		return err
	}
	if parallel == 0 {
		return nil
	}
	limitMu.Lock()
	defer limitMu.Unlock()
	if err := ctx.Err(); err != nil {
		return err
	}
	required := uint64(128 + 16*parallel)
	failure := &LimitError{Parallel: parallel, Required: required}
	var limit unix.Rlimit
	if unix.Getrlimit(unix.RLIMIT_NOFILE, &limit) != nil {
		return failure
	}
	if limit.Cur >= required {
		return nil
	}
	if limit.Max < required {
		return failure
	}
	limit.Cur = required
	if unix.Setrlimit(unix.RLIMIT_NOFILE, &limit) != nil {
		return failure
	}
	return nil
}
